#!/usr/bin/python3

def _main() -> None:
    n = int(input().strip())
    aristas = map(int, input().strip().split())

if __name__ == '__main__':
    _main()
