#!/usr/bin/python3

def _main() -> None:
    a, b = map(int, input().strip().split())
    print(a + b)

if __name__ == '__main__':
    _main()
