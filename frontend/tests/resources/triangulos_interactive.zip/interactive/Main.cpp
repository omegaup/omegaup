#include <iostream>

#include "triangulos.h"

int main() {
  std::cin.tie(0);
  std::ios_base::sync_with_stdio(0);

  int N, palos[50];
  while (std::cin >> N) {
    for (int i = 0; i < N; ++i)
      std::cin >> palos[i];
    std::cout << perimetro(N, palos) << "\n";
  }

  return 0;
}
