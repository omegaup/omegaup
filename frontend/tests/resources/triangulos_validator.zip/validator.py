#!/usr/bin/python3
# -*- coding: utf-8 -*-

import logging
import sys


def _main():
    with open('data.out', 'r') as f:
        expected = int(f.read().strip())

    score = 0
    try:
        got = int(input().strip())

        if got != expected:
            print('Wrong answer', file=sys.stderr)
            return

        score = 1
    except:
        logging.exception('Wrong output format')
    finally:
        print(score)


if __name__ == '__main__':
    _main()
