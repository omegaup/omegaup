from __future__ import print_function

print(sum(int(x) for x in raw_input().strip().split()))
