#include <stdio.h>

//Estructura de Pila, espec�fica para el programa, donde los elementos son char y el tama�o es 2000
struct Pila{
	char arreglo[2002];
	short int posActual;

	//Devuelve si la pila est� vacia
	bool estaVacia(){
		return posActual == 0;
	}

	//inserta un elemento en cima de la pila
	void push(char valor){
		posActual++;
		arreglo[posActual] = valor; 
	}

	//quita el elemento de la cima de la pila y lo devuelve
	char pop(){
		char valor = 0;
		if(!estaVacia()){
			valor = arreglo[posActual];
			posActual--;
		}
		return valor;
	}

	//devuelve el valor del elemento de la cima de la pila
	char top(){
		return arreglo[posActual];
	}

};

int M, N;
int G, C;
int K;
int Ci, Mi, Ni, Xi, Yi; 

Pila cartulina[202][202];


int main(){
	//Leemos los datos de la cartulina
	scanf("%d%d", &M, &N);
	scanf("%d%d", &G, &C);
	//inicializamos las G capas de la cartulina
	for(int i = 1; i <= N; i++){
		for(int j = 1; j <=M; j++){
			for(int k = 1; k <= G; k++){
				cartulina[i][j].push(C);
			}
		}
	}
	//Leemos y procesamos los rectangulos
	scanf("%d", &K);
	for(int r = 1; r <= K; r++){
		scanf("%d%d%d%d%d", &Ci, &Mi, &Ni, &Xi, &Yi);
		//checamos si se trata de un rectangulo adhesivo
		if(Ci == -1){
			//desgarramos el papel
			for(int i = Yi + Ni - 1; i >= Yi; i--){
				for(int j = Xi + Mi - 1; j >= Xi; j--){
					if(!cartulina[i][j].estaVacia()){		
						cartulina[i][j].pop();
					}
				}
			}
		}
		else{
			//a�adimos la capa de papel
			for(int i = Yi + Ni - 1; i >= Yi; i--){
				for(int j = Xi + Mi - 1; j >= Xi; j--){
					cartulina[i][j].push(Ci);
				}
			}
		}
	
	}

	//imprimimos el resultado
	for(int i = 1; i <= N; i++){
		for(int j = 1; j <=M; j++){
			//checamos si no quedan capas de papel
			if(cartulina[i][j].estaVacia()){
				printf("-1 ");
			}
			else{
				printf("%d ", cartulina[i][j].top());
			}
		}
		printf("\n");
	}

	return 0;
}




