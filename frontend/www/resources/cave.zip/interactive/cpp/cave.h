#ifndef CAVE_H
#define CAVE_H
void exploreCave(int);
void answer(int[], int[]);
int tryCombination(int[]);
#endif // CAVE_H
