#include "cave.h"
#include <cstdio>
#include <cstring>
#include <algorithm>

using namespace std;

// Todas las variables globales deben ser declaradas en el anonymous namespace
// para prevenir que los programas de los concursantes adivinen los nombres de
// las variables y las usen en sus programas.
namespace {
	int N;
	int down[5000];
	int door[5000];
	int tries = 0;
	const int maxTries = 70000;
}

int tryCombination(int S[]) {
	if (tries++ == maxTries) {
		printf("Max tries exceeded\n");
		exit(1);
	}

	for (int i = 0; i < N; i++) {
		if (down[door[i]] != S[door[i]]) {
			return i;
		}
	}

	return -1;
}

void answer(int S[], int D[]) {
	// Esto es opcional, pero en caso de que los concursantes logren
	// obtener apuntadores directos a las variables globales mediante
	// trucos sucios difíciles de mitigar en C/C++, se pueden detectar
	// esos casos. Claro que nada impide que el concursante copie los
	// contenidos de esos arreglos en arreglos propios.
	if (S == down || D == door) {
		printf("Cheating\n");
		exit(1);
	}

	for (int i = 0; i < N; i++) {
		printf(i == 0 ? "%d" : " %d", S[i]);
	}
	printf("\n");
	for (int i = 0; i < N; i++) {
		printf(i == 0 ? "%d" : " %d", D[i]);
	}
	printf("\n");

	exit(0);
}

int main(int argc, char* argv[]) {
	scanf("%d\n", &N);
	for (int i = 0; i < N; i++) {
		scanf("%d", &down[i]);
	}
	for (int i = 0; i < N; i++) {
		int idx;
		scanf("%d", &idx);
		door[idx] = i;
	}

	// Cerrar stdin después de terminar la lectura es muy importante,
	// porque el concursante puede fácilmente darle fseek(0, SEEK_SET)
	// y después volver a leer todo el input usando scanf.
	fclose(stdin);

	exploreCave(N);

	return 1;
}
