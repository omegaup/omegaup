#ifndef SOLVE_H
#define SOLVE_H

long long solve(long long, long long);

#endif // SOLVE_H
