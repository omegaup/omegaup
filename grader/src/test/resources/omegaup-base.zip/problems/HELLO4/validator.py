data = open("data.in", "r")
a, b = map(float, data.readline().strip().split())
user = float(raw_input().strip())
answer = a**2 + b**2
print 1.0 / (1.0 + (answer - user)**2)
